import { Component, ElementRef, inject, viewChildren } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { Dozent, Rating } from '../../models/rating';
import { RatingFetchService } from '../../services/ratingfetch.service';
import { DozentenService } from '../../services/dozenten.service';

@Component({
  selector: 'app-rating',
  imports: [ReactiveFormsModule],
  templateUrl: './rating.component.html',
  styleUrl: './rating.component.scss',
})
export class RatingComponent {
  ratingForm!: FormGroup;
  ratings: Rating[] = [];
  dozent: Dozent[] = [];
  setRating = inject(RatingFetchService);
  dozenten = inject(DozentenService);
  description = viewChildren<ElementRef>('info');
  maxLength = 255;

  constructor(private fb: FormBuilder) {
    this.initForm();
  }

  ngOnInit() {
    this.dozent = this.dozenten.getItems();
  }

  private initForm(): void {
    this.ratingForm = this.fb.group({
      name: ['', Validators.required],
      mail: ['', Validators.required],
      dozent: ['', Validators.required],
      fach: ['', Validators.required],
      sterne: ['', Validators.required],
      kommentar: ['', Validators.maxLength(this.maxLength)],
    });
  }

  get charCount(): number {
    return this.ratingForm.get('kommentar')?.value?.length || 0;
  }

  submit() {
    if (this.ratingForm.invalid) {
      alert('Bitte alle Felder ausfüllen!');
      return;
    }

    const newRating: Rating = this.ratingForm.value;
    console.log(JSON.stringify(newRating));

    this.setRating.setRatingData(newRating).subscribe({
      next: () => {
        alert('Erfolgreich abgeschickt!');
      },
      error: (err) => {
        alert('Es ist ein Fehler aufgetreten: ' + err);
      },
    });
  }

  dozClick(index: number) {
    this.description()?.forEach((el, i) => {
      const overlay = el.nativeElement as HTMLElement;
      const infoBox = overlay.querySelector('.doz-info') as HTMLElement;

      if (i === index) {
        overlay.style.display = 'block';
        if (infoBox) infoBox.style.display = 'flex'; // oder 'block'
      } else {
        overlay.style.display = 'none';
        if (infoBox) infoBox.style.display = 'none';
      }
    });
  }

  closePopup() {
    this.description().forEach((el) => {
      const overlay = el.nativeElement as HTMLElement;
      const infoBox = overlay.querySelector('.doz-info') as HTMLElement;

      overlay.style.display = 'none';
      if (infoBox) {
        infoBox.style.display = 'none';
      }
    });
  }
}
