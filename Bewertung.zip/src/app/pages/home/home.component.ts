import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  imports: [CommonModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss',
})
export class HomeComponent {
  isActive = false;

  changeBoolean(event: Event) {
    this.isActive = !this.isActive;
  }

  sieger = [
    { name: 'Jacques', platz: 3 },
    { name: 'zweiter', platz: 1 },
    { name: 'dritter', platz: 2 },
  ];
}
