import { Component, ElementRef, inject, viewChildren } from '@angular/core';
import { DozentenService } from '../../services/dozenten.service';
import { Dozent } from '../../models/rating';

@Component({
  selector: 'app-contact',
  imports: [],
  templateUrl: './contact.component.html',
  styleUrl: './contact.component.scss',
})
export class ContactComponent {
  dozent: Dozent[] = [];
  dozenten = inject(DozentenService);
  description = viewChildren<ElementRef>('info');

  ngOnInit() {
    this.dozent = this.dozenten.getItems();
  }

  dozClick(index: number) {
    this.description()?.forEach((el, i) => {
      const overlay = el.nativeElement as HTMLElement;
      const infoBox = overlay.querySelector('.doz-info') as HTMLElement;

      if (i === index) {
        overlay.style.display = 'block';
        if (infoBox) infoBox.style.display = 'flex'; // oder 'block'
      } else {
        overlay.style.display = 'none';
        if (infoBox) infoBox.style.display = 'none';
      }
    });
  }

  closePopup() {
    this.description().forEach((el) => {
      const overlay = el.nativeElement as HTMLElement;
      const infoBox = overlay.querySelector('.doz-info') as HTMLElement;

      overlay.style.display = 'none';
      if (infoBox) {
        infoBox.style.display = 'none';
      }
    });
  }
}
