import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Rating } from '../models/rating';

@Injectable({
  providedIn: 'root',
})
export class RatingFetchService {
  constructor(private http: HttpClient) {} // Kein Import von HttpClientModule hier!

  getRatingData() {
    return this.http.get<Rating[]>(
      'https://159.69.36.137:5001/api/Bewertung/',
      {}
    );
  }

  setRatingData(data: Rating) {
    return this.http.post<Rating[]>(
      'https://159.69.36.137:5001/api/Bewertung/',
      data
    );
  }
}
