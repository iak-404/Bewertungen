import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class DozentenService {
  private items = [
    {
      id: 1,
      name: 'Jacqui the Doll',
      avatar: 'Jacqui.png',
      description:
        'Ein Dozent der Neuzeit. Beschäftigt sich mit mörderischem Code in blutroter Farbe. Verlangt seinen Schülern alles ab, auch wenn sie bis zum Tode verzweifeln, aber dennoch ist der Unterricht höllisch gut.',
    },
    {
      id: 2,
      name: 'Ali Mustafa',
      avatar: 'dummy.png',
      description: 'Ali gut',
    },
    {
      id: 3,
      name: 'Jacqui the Doll',
      avatar: 'dummy.png',
      description:
        'Ein Dozent der Neuzeit. Beschäftigt sich mit mörderischem Code in blutroter Farbe. Verlangt seinen Schülern alles ab, auch wenn sie bis zum Tode verzweifeln, aber dennoch ist der Unterricht höllisch gut.',
    },
    {
      id: 4,
      name: 'Jacqui the Doll',
      avatar: 'dummy.png',
      description:
        'Ein Dozent der Neuzeit. Beschäftigt sich mit mörderischem Code in blutroter Farbe. Verlangt seinen Schülern alles ab, auch wenn sie bis zum Tode verzweifeln, aber dennoch ist der Unterricht höllisch gut.',
    },
    {
      id: 5,
      name: 'Jacqui the Doll',
      avatar: 'dummy.png',
      description:
        'Ein Dozent der Neuzeit. Beschäftigt sich mit mörderischem Code in blutroter Farbe. Verlangt seinen Schülern alles ab, auch wenn sie bis zum Tode verzweifeln, aber dennoch ist der Unterricht höllisch gut.',
    },
    {
      id: 6,
      name: 'Jacqui the Doll',
      avatar: 'Jacqui.png',
      description:
        'Ein Dozent der Neuzeit. Beschäftigt sich mit mörderischem Code in blutroter Farbe. Verlangt seinen Schülern alles ab, auch wenn sie bis zum Tode verzweifeln, aber dennoch ist der Unterricht höllisch gut.',
    },
    {
      id: 7,
      name: 'Jacqui the Doll',
      avatar: 'dummy.png',
      description:
        'Ein Dozent der Neuzeit. Beschäftigt sich mit mörderischem Code in blutroter Farbe. Verlangt seinen Schülern alles ab, auch wenn sie bis zum Tode verzweifeln, aber dennoch ist der Unterricht höllisch gut.',
    },
    {
      id: 8,
      name: 'Jacqui the Doll',
      avatar: 'dummy.png',
      description:
        'Ein Dozent der Neuzeit. Beschäftigt sich mit mörderischem Code in blutroter Farbe. Verlangt seinen Schülern alles ab, auch wenn sie bis zum Tode verzweifeln, aber dennoch ist der Unterricht höllisch gut.',
    },
    {
      id: 9,
      name: 'Jacqui the Doll',
      avatar: 'dummy.png',
      description:
        'Ein Dozent der Neuzeit. Beschäftigt sich mit mörderischem Code in blutroter Farbe. Verlangt seinen Schülern alles ab, auch wenn sie bis zum Tode verzweifeln, aber dennoch ist der Unterricht höllisch gut.',
    },
    {
      id: 10,
      name: 'Jacqui the Doll',
      avatar: 'dummy.png',
      description:
        'Ein Dozent der Neuzeit. Beschäftigt sich mit mörderischem Code in blutroter Farbe. Verlangt seinen Schülern alles ab, auch wenn sie bis zum Tode verzweifeln, aber dennoch ist der Unterricht höllisch gut.',
    },
  ];

  getItems() {
    return this.items;
  }

  constructor() {}
}
